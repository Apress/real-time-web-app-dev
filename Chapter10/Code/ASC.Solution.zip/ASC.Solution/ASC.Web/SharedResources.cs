﻿namespace ASC.Web
{
    public class SharedResources
    {
    }
}
