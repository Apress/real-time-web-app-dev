# AutomobileServiceCenter.Core
Public Repository of Automobile Service Center ASP.NET Core Web Application.

[![Build Status](https://travis-ci.org/AutomobileServiceCenter/AutomobileServiceCenter.Core.svg?branch=dev)](https://travis-ci.org/AutomobileServiceCenter/AutomobileServiceCenter.Core)
